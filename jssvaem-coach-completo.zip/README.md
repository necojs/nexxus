# JSSVAEM COACH - Deployment GitHub → Netlify

Tu mentor estoico personal con backend serverless integrado.

---

## 📦 ARCHIVOS EN ESTE PROYECTO:

- **index.html** - La app completa (frontend)
- **netlify.toml** - Configuración de Netlify
- **netlify/functions/chat.js** - Backend serverless (hace las llamadas a Anthropic API)

---

## 🚀 INSTALACIÓN PASO A PASO (5 minutos):

### **PASO 1: Subir a GitHub** (2 min)

1. Ve a tu repositorio: https://github.com/sebastianneco1-coder/command-center

2. Click en **"Add file"** → **"Upload files"**

3. Arrastra estos archivos:
   - `index.html`
   - `netlify.toml`
   - La carpeta `netlify` completa

4. Click **"Commit changes"**

### **PASO 2: Conectar Netlify a GitHub** (2 min)

1. Ve a: https://app.netlify.com/

2. Click **"Add new site"** → **"Import an existing project"**

3. Click **"GitHub"**

4. Busca y selecciona: **"command-center"**

5. Configuración:
   - Branch: main
   - Build command: (vacío)
   - Publish directory: (vacío)

6. Click **"Deploy site"**

### **PASO 3: Esperar deployment** (1 min)

Netlify despliega automáticamente. Espera hasta ver "Site is live".

### **PASO 4: Abrir en iPhone**

1. Copia el link de Netlify
2. Mándate el link a tu iPhone
3. Abre en Safari
4. Compartir → "Añadir a pantalla de inicio"

---

## ✅ TODAS LAS FUNCIONES INCLUIDAS:

- Mentor Estoico Personal (Marco Aurelio, Séneca, Epicteto)
- Sistema de Aprendizaje Automático
- Reflexión Estoica Diaria
- Comandos Rápidos
- Gestión de Tareas
- Todo tu contexto personal (NexxusCars, proyectos)
- Skill sebastiannew-mind completa

**NADA SE PERDIÓ. TODO ESTÁ AQUÍ.**
